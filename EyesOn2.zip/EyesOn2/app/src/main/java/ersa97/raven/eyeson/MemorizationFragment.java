package ersa97.raven.eyeson;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MemorizationFragment extends Fragment {

    String [] surat = {"An-Naba","An-Nazi'at","'Abasa","At-Takwir","Al-Infitar","Al-Muthaffifin",
    "Al-Inshiqaq","Al-Buruj","At-Tariq","Al-A'la"};


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_memorization, container, false);


        ListView listView = (ListView) view.findViewById(R.id.ListViewHafalan);

        CustomAdapter customAdapter = new CustomAdapter();

        listView.setAdapter(customAdapter);


        return view;
    }
    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return surat.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = getLayoutInflater().inflate(R.layout.memorization_detail,null);


            TextView textView1 = (TextView)view.findViewById(R.id.hafalan);

            textView1.setText(surat[i]);

            return view;
        }
    }

}
