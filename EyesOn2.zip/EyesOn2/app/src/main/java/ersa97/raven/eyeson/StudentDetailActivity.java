package ersa97.raven.eyeson;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class StudentDetailActivity extends AppCompatActivity {



    String nama, deskripsi;
    TextView textViewNama;
    TextView textViewAlamat;
    TextView textViewDeskripsi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);

        Bundle extra = getIntent().getExtras();

            nama = extra.getString("nama");
            deskripsi = extra.getString("usia");

        textViewNama = (TextView)findViewById(R.id.textView_Name);
        textViewDeskripsi= (TextView) findViewById(R.id.textView_Deskripsi);

        textViewNama.setText(nama);
        textViewDeskripsi.setText(deskripsi);
        /*textView.setText(TempName);
        imageView.setImageResource(TempImage);*/


        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()){
                        case R.id.nav_nilai:
                            selectedFragment= new GradeFragment();
                            break;
                        case R.id.nav_hafalan:
                            selectedFragment = new MemorizationFragment();
                            break;
                        case R.id.nav_profile:
                            selectedFragment = new ProfileFragment();
                            break;
                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            selectedFragment).commit();

                    return true;
                }
            };
}
