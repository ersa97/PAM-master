package ersa97.raven.eyeson;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;

public class StudentsAdapter extends FirestoreRecyclerAdapter<Students, StudentsAdapter.StudentHolder>{
    private OnItemClickListener listener;

    public StudentsAdapter(@NonNull FirestoreRecyclerOptions<Students> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull StudentHolder holder, int position, final @NonNull Students model) {
        holder.textViewNama.setText(model.getNama());
        holder.textViewAlamat.setText(model.getAlamat());
        holder.textViewDeskripsi.setText(model.getDeskripsi());
        holder.card_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = model.getNama();
                String deskripsi = model.getDeskripsi();

                Intent intent = new Intent(v.getContext(),StudentDetailActivity.class);
                intent.putExtra("nama", nama);
                intent.putExtra("usia", deskripsi);
                v.getContext().startActivity(intent);
            }
        });
    }

    @NonNull
    @Override
    public StudentHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item, viewGroup, false);
        return new StudentHolder(view);
    }

    public void deleteItem(int position){
        getSnapshots().getSnapshot(position).getReference().delete();

    }

    class StudentHolder extends RecyclerView.ViewHolder{
        TextView textViewNama;
        TextView textViewAlamat;
        TextView textViewDeskripsi;
        CardView card_item;

        public StudentHolder(@NonNull View itemView) {
            super(itemView);
            textViewNama = itemView.findViewById(R.id.show_nama);
            textViewAlamat = itemView.findViewById(R.id.show_alamat);
            textViewDeskripsi = itemView.findViewById(R.id.show_deskripsi);
            card_item = itemView.findViewById(R.id.card_item);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position != RecyclerView.NO_POSITION && listener !=null){
                        listener.onItemClick(getSnapshots().getSnapshot(position), position);
                    }
                }
            });
        }
    }

    public interface OnItemClickListener{
        void onItemClick(DocumentSnapshot documentSnapshot, int position);
    }

    public void setOnItemClickLlistener(OnItemClickListener listener){
        this.listener = listener;
    }
}
