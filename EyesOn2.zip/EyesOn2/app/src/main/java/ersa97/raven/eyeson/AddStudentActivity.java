package ersa97.raven.eyeson;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ToolbarWidgetWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class AddStudentActivity extends AppCompatActivity {

    EditText editTextNama;
    EditText editTextAlamat;
    EditText editTextDeskripsi;

    private Toolbar mToolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);


        editTextNama = findViewById(R.id.nama_Student);
        editTextAlamat = findViewById(R.id.alamat);
        editTextDeskripsi = findViewById(R.id.deskripsi);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.add_save:
                save_student();
                return true;
                default:
                    return super.onOptionsItemSelected(item);
        }
    }

    private void save_student(){
        String nama = editTextNama.getText().toString();
        String alamat = editTextAlamat.getText().toString();
        String deskripsi = editTextDeskripsi.getText().toString();

        if (nama.trim().isEmpty() || alamat.trim().isEmpty() || deskripsi.trim().isEmpty()){
            Toast.makeText(this, "Mohon masukan nama, alamat dan usia", Toast.LENGTH_SHORT).show();
            return;
        }

        CollectionReference reference = FirebaseFirestore.getInstance().collection("Student");
        reference.add(new Students(nama, alamat, deskripsi));
        Toast.makeText(this, "Murid ditambahkan", Toast.LENGTH_SHORT).show();
        finish();

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
